export default {
  youtube: "AIzaSyDcqJwobzY5H-S5EMfTUSbSsDIJDCKR6ko", //key=AIzaSyDcqJwobzY5H-S5EMfTUSbSsDIJDCKR6ko
  weather: "17e1e822-e684-4791-a82a-a460dd167150",//"d49b336f-e8f5-3af1-b5f0-b165dc65a309", //stnid=d49b336f-e8f5-3af1-b5f0-b165dc65a309
  finedust: "ef208550-67aa-47c8-9b57-b0ffad3075e4", //key=ef208550-67aa-47c8-9b57-b0ffad3075e4
  googleCalendar: {
    CLIENT_ID: '147844597550-434pm8jr77c67nfb3o108s8hudfmqie5.apps.googleusercontent.com',
    API_KEY: 'AIzaSyAzsRxk0sb5LzkoCEJijdRA8TEg0dnfSh0'
    // CLIENT_ID: '285876530910-puioub7pjqlji4i30ej5irvpog14hmbo.apps.googleusercontent.com',
    // API_KEY: 'AIzaSyD17_13yKTheoV8C6ZKXwGFm0RODhEaYFU'
  },
}
